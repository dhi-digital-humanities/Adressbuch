<?php
/*
Info Page Related Articles
*/
?>

<div class="row">
    <?= $this->element('sideNav', ['mapBox' => false, 'export' => 'simple'])?>
    <div class="column-responsive column-80">
		<div class="content">
			<h3><?= __('Publikationen') ?></h3>
			<p>Hier kann man Veröffentlichungen zum Projekt finden!</p>
		</div>
	</div>
</div>
