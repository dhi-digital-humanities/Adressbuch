<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * BHVP300 Entity
 *
 * @property int $id
 * @property string|null $name
 * @property int $resolution
 * @property string|null $size
 * @property bool |null $img
 *
 *
 * @property \App\Model\Entity\LdhRank $ldh_rank
 * @property \App\Model\Entity\MilitaryStatus $military_status
 * @property \App\Model\Entity\SocialStatus $social_status
 * @property \App\Model\Entity\OccupationStatus $occupation_status
 * @property \App\Model\Entity\ProfCategory $prof_category
 * @property \App\Model\Entity\Address[] $addresses
 * @property \App\Model\Entity\Company[] $companies
 * @property \App\Model\Entity\ExternalReference[] $external_references
 * @property \App\Model\Entity\OriginalReference[] $original_references
 * @property \App\Model\Entiy\Person [] $persons
 */
class BHVP300 extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'name' => true,
        'resolution' => true,
        'size' => true,
        'img' => true,
        'ldh_rank' => true,
        'military_status' => true,
        'social_status' => true,
        'occupation_status' => true,
        'prof_category' => true,
        'addresses' => true,
        'companies' => true,
        'external_references' => true,
        'original_references' => true,
        'persons' => true,
        
        
    ];
}
