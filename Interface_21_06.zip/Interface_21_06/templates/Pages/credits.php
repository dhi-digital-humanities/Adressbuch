<?php
/*
Credits
*/
?>

<div class="row">
    <?= $this->element('sideNav', ['mapBox' => false, 'export' => 'simple'])?>
    <div class="column-responsive column-80">
		<div class="content">
			<h3><?= __('Impressum') ?></h3>
			<p>DHI Paris 2020 und weitere Credits</p>
		</div>
	</div>
</div>
