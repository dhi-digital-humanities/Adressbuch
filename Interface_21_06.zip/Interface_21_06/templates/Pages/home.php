<?php
/*
Homepage
*/
?>

<div class="row">
    <?= $this->element('sideNav', ['mapBox' => false, 'export' => 'simple'])?>
    <div class="column-responsive column-80">
		<div class="content">
			<h3><?= __('Willkommen') ?></h3>
			<p>Hier kann eine schöne Ankunftsseite erscheinen!</p>
		</div>
	</div>
</div>
